import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export function FundingProgress() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Funding Progress</CardTitle>
        <CardDescription>Track your educational funding progress</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium">Overall Funding</h4>
              <span className="text-sm text-muted-foreground">75%</span>
            </div>
            <Progress value={75} />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium">Tuition</h4>
              <span className="text-sm text-muted-foreground">90%</span>
            </div>
            <Progress value={90} />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium">Living Expenses</h4>
              <span className="text-sm text-muted-foreground">60%</span>
            </div>
            <Progress value={60} />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium">Books & Materials</h4>
              <span className="text-sm text-muted-foreground">45%</span>
            </div>
            <Progress value={45} />
          </div>
        </div>
        <div className="mt-8 rounded-md bg-muted/20 p-4">
          <h3 className="font-medium">Funding Goal: $16,500</h3>
          <p className="text-sm text-muted-foreground mt-1">Current: $12,500 (75%)</p>
          <p className="text-sm text-muted-foreground mt-1">Remaining: $4,000</p>
        </div>
      </CardContent>
    </Card>
  )
}
