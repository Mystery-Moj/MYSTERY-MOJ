import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function InvestmentOverview() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Investment Overview</CardTitle>
        <CardDescription>Your investment portfolio performance over time</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] flex items-center justify-center bg-muted/20 rounded-md">
          <p className="text-muted-foreground">Investment chart will be displayed here</p>
        </div>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div className="bg-muted/20 p-4 rounded-md">
            <h3 className="font-medium">Portfolio Diversity</h3>
            <p className="text-sm text-muted-foreground">8 students across 3 universities</p>
          </div>
          <div className="bg-muted/20 p-4 rounded-md">
            <h3 className="font-medium">Average ROI</h3>
            <p className="text-sm text-muted-foreground">12.5% annually</p>
          </div>
          <div className="bg-muted/20 p-4 rounded-md">
            <h3 className="font-medium">Risk Assessment</h3>
            <p className="text-sm text-muted-foreground">Moderate</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
