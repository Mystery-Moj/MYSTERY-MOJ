import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function InvestorsList() {
  const investors = [
    {
      id: "1",
      name: "Robert Smith",
      investmentAmount: "$5,000",
      date: "2023-02-15",
      status: "Active",
    },
    {
      id: "2",
      name: "Jennifer Lee",
      investmentAmount: "$3,500",
      date: "2023-03-01",
      status: "Active",
    },
    {
      id: "3",
      name: "Michael Brown",
      investmentAmount: "$2,000",
      date: "2023-03-10",
      status: "Active",
    },
    {
      id: "4",
      name: "Emily Davis",
      investmentAmount: "$1,500",
      date: "2023-03-22",
      status: "Active",
    },
    {
      id: "5",
      name: "Thomas Wilson",
      investmentAmount: "$500",
      date: "2023-04-01",
      status: "Active",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Investors</CardTitle>
        <CardDescription>People who have invested in your education</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          <div className="rounded-md border">
            <div className="relative w-full overflow-auto">
              <table className="w-full caption-bottom text-sm">
                <thead>
                  <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                    <th className="h-12 px-4 text-left align-middle font-medium">Name</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Investment Amount</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Date</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Status</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {investors.map((investor) => (
                    <tr
                      key={investor.id}
                      className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                    >
                      <td className="p-4 align-middle">{investor.name}</td>
                      <td className="p-4 align-middle">{investor.investmentAmount}</td>
                      <td className="p-4 align-middle">{investor.date}</td>
                      <td className="p-4 align-middle">
                        <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium bg-green-100 text-green-800">
                          {investor.status}
                        </span>
                      </td>
                      <td className="p-4 align-middle">
                        <Button size="sm" variant="outline">
                          Send Message
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
