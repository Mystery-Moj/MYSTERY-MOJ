import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function RecentTransactions() {
  const transactions = [
    {
      id: "1",
      date: "2023-04-01",
      description: "Investment Deposit",
      amount: "$2,500",
      status: "completed",
    },
    {
      id: "2",
      date: "2023-03-25",
      description: "Tuition Payment",
      amount: "$1,800",
      status: "completed",
    },
    {
      id: "3",
      date: "2023-03-15",
      description: "Investment Deposit",
      amount: "$1,000",
      status: "completed",
    },
    {
      id: "4",
      date: "2023-03-10",
      description: "Books & Materials",
      amount: "$350",
      status: "completed",
    },
    {
      id: "5",
      date: "2023-03-01",
      description: "Monthly Stipend",
      amount: "$800",
      status: "completed",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
        <CardDescription>Your recent financial activities</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          <div className="rounded-md border">
            <div className="relative w-full overflow-auto">
              <table className="w-full caption-bottom text-sm">
                <thead>
                  <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                    <th className="h-12 px-4 text-left align-middle font-medium">Date</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Description</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Amount</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((transaction) => (
                    <tr
                      key={transaction.id}
                      className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                    >
                      <td className="p-4 align-middle">{transaction.date}</td>
                      <td className="p-4 align-middle">{transaction.description}</td>
                      <td className="p-4 align-middle">{transaction.amount}</td>
                      <td className="p-4 align-middle">
                        <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium bg-green-100 text-green-800">
                          {transaction.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
