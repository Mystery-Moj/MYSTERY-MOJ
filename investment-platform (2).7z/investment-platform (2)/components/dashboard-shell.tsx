import type React from "react"
interface DashboardShellProps {
  children: React.ReactNode
}

export function DashboardShell({ children }: DashboardShellProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2 font-bold text-xl">
            <span className="text-primary">Moj</span>
            <span>Invest</span>
          </div>
          <nav className="flex items-center gap-4">
            <a href="/dashboard" className="text-sm font-medium hover:underline">
              Dashboard
            </a>
            <a href="/profile" className="text-sm font-medium hover:underline">
              Profile
            </a>
            <a href="/settings" className="text-sm font-medium hover:underline">
              Settings
            </a>
            <a href="/logout" className="text-sm font-medium hover:underline">
              Logout
            </a>
          </nav>
        </div>
      </header>
      <main className="flex-1 space-y-4 p-8 pt-6">
        <div className="container">{children}</div>
      </main>
    </div>
  )
}
