import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function StudentsList() {
  const students = [
    {
      id: "1",
      name: "Alex Johnson",
      university: "Stanford University",
      major: "Computer Science",
      fundingGoal: "$15,000",
      funded: "80%",
    },
    {
      id: "2",
      name: "Maria Garcia",
      university: "MIT",
      major: "Electrical Engineering",
      fundingGoal: "$18,000",
      funded: "65%",
    },
    {
      id: "3",
      name: "David Kim",
      university: "Harvard University",
      major: "Business Administration",
      fundingGoal: "$20,000",
      funded: "45%",
    },
    {
      id: "4",
      name: "Sarah Patel",
      university: "UC Berkeley",
      major: "Data Science",
      fundingGoal: "$16,500",
      funded: "70%",
    },
    {
      id: "5",
      name: "James Wilson",
      university: "Princeton University",
      major: "Physics",
      fundingGoal: "$17,000",
      funded: "55%",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Students</CardTitle>
        <CardDescription>Students you are currently investing in</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          <div className="rounded-md border">
            <div className="relative w-full overflow-auto">
              <table className="w-full caption-bottom text-sm">
                <thead>
                  <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                    <th className="h-12 px-4 text-left align-middle font-medium">Name</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">University</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Major</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Funding Goal</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Funded</th>
                    <th className="h-12 px-4 text-left align-middle font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((student) => (
                    <tr
                      key={student.id}
                      className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                    >
                      <td className="p-4 align-middle">{student.name}</td>
                      <td className="p-4 align-middle">{student.university}</td>
                      <td className="p-4 align-middle">{student.major}</td>
                      <td className="p-4 align-middle">{student.fundingGoal}</td>
                      <td className="p-4 align-middle">{student.funded}</td>
                      <td className="p-4 align-middle">
                        <Button size="sm" variant="outline">
                          View Profile
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
