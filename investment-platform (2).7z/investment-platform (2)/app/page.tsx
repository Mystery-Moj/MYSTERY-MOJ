import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-xl">
            <span className="text-primary">Moj</span>
            <span>Invest</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/login" className="text-sm font-medium hover:underline">
              Login
            </Link>
            <Button asChild>
              <Link href="/register">Get Started</Link>
            </Button>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                  Invest in Student Success
                </h1>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                  Connect with promising students and fund their education for mutual growth and returns.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button asChild size="lg">
                  <Link href="/register?role=investor">Become an Investor</Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link href="/register?role=student">Join as a Student</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="mx-auto grid max-w-5xl items-center gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">For Investors</h2>
                <p className="text-gray-500 dark:text-gray-400">
                  Diversify your portfolio by investing in education. Support talented students and earn returns as they
                  succeed in their careers.
                </p>
                <ul className="grid gap-2">
                  <li className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-primary" />
                    <span>Access to vetted student profiles</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-primary" />
                    <span>Multiple investment plans</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-primary" />
                    <span>Track your investments in real-time</span>
                  </li>
                </ul>
              </div>
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">For Students</h2>
                <p className="text-gray-500 dark:text-gray-400">
                  Get the funding you need to pursue your education and career goals. Connect with investors who believe
                  in your potential.
                </p>
                <ul className="grid gap-2">
                  <li className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-primary" />
                    <span>Create a compelling profile</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-primary" />
                    <span>Receive funding for your education</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-primary" />
                    <span>Build valuable connections</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto grid max-w-5xl gap-8">
              <div className="flex flex-col items-center justify-center space-y-4 text-center">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Investment Plans</h2>
                <p className="max-w-[700px] text-gray-500 dark:text-gray-400">
                  Choose the investment plan that suits your goals and risk tolerance.
                </p>
              </div>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle>Starter</CardTitle>
                    <CardDescription>For new investors testing the waters</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">$500</div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Minimum investment</p>
                    <ul className="mt-4 grid gap-2">
                      <li className="flex items-center gap-2">
                        <ArrowRight className="h-4 w-4 text-primary" />
                        <span>Access to 5 student profiles</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <ArrowRight className="h-4 w-4 text-primary" />
                        <span>Basic dashboard</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <ArrowRight className="h-4 w-4 text-primary" />
                        <span>Email support</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" asChild>
                      <Link href="/register?role=investor&plan=starter">Get Started</Link>
                    </Button>
                  </CardFooter>
                </Card>
                <Card className="border-primary">
                  <CardHeader>
                    <CardTitle>Growth</CardTitle>
                    <CardDescription>Our most popular investment plan</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">$2,000</div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Minimum investment</p>
                    <ul className="mt-4 grid gap-2">
                      <li className="flex items-center gap-2">
                        <ArrowRight className="h-4 w-4 text-primary" />
                        <span>Access to 20 student profiles</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <ArrowRight className="h-4 w-4 text-primary" />
                        <span>Advanced analytics</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <ArrowRight className="h-4 w-4 text-primary" />
                        <span>Priority support</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" asChild>
                      <Link href="/register?role=investor&plan=growth">Get Started</Link>
                    </Button>
                  </CardFooter>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Premium</CardTitle>
                    <CardDescription>For serious education investors</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">$5,000</div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Minimum investment</p>
                    <ul className="mt-4 grid gap-2">
                      <li className="flex items-center gap-2">
                        <ArrowRight className="h-4 w-4 text-primary" />
                        <span>Unlimited student profiles</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <ArrowRight className="h-4 w-4 text-primary" />
                        <span>Dedicated account manager</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <ArrowRight className="h-4 w-4 text-primary" />
                        <span>Early access to top students</span>
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" asChild>
                      <Link href="/register?role=investor&plan=premium">Get Started</Link>
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            © {new Date().getFullYear()} Moj Invest. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-gray-500 hover:underline dark:text-gray-400">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-gray-500 hover:underline dark:text-gray-400">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-gray-500 hover:underline dark:text-gray-400">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
